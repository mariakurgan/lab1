package com.tttea;

public interface Consumable {
    public abstract void consume();

}
